﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace App_Bunifu_UI
{
    public partial class tab1 : UserControl
    {
        public tab1()
        {
            InitializeComponent();
        }
    }
}
